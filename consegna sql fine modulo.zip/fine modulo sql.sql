CREATE DATABASE DB_CONSEGNAFINEMODULO

USE DB_CONSEGNAFINEMODULO

-- Creazione della tabella "Category"
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(255) NOT NULL
);

-- Creazione della tabella "Product"
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(255) NOT NULL,
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

-- Creazione della tabella "Region"
CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(255) NOT NULL
);

-- Creazione della tabella "State"
CREATE TABLE State (
    StateID INT PRIMARY KEY,
    StateName VARCHAR(255) NOT NULL,
    RegionID INT,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Creazione della tabella "Sales"
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
	FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Popolamento della tabella "Category"
INSERT INTO Category (CategoryID, CategoryName) VALUES
(1, 'Bikes'),
(2, 'Clothing'),
(3, 'Toys');

-- Popolamento della tabella "Product"
INSERT INTO Product (ProductID, ProductName, CategoryID) VALUES
(101, 'Bike-100', 1),
(102, 'Bike-200', 1),
(201, 'Bike Glove M', 2),
(202, 'Bike Gloves L', 2),
(301, 'Toy-001', 3);

-- Popolamento della tabella "Region"
INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'WestEurope'),
(2, 'SouthEurope'),
(3, 'NorthAmerica');

-- Popolamento della tabella "State"
INSERT INTO State (StateID, StateName, RegionID) VALUES
(11, 'France', 1),
(12, 'Germany', 1),
(21, 'Italy', 2),
(22, 'Greece', 2),
(31, 'USA', 3),
(32, 'Canada', 3);

-- Popolamento della tabella "Sales"
INSERT INTO Sales (SaleID, ProductID, RegionID) VALUES
(1001, 101, 11),
(1002, 102, 12),
(1003, 201, 21),
(1004, 202, 22),
(1005, 301, 31);

--Verificare l'univocit� delle chiavi primarie: Per la tabella "Category"
SELECT CategoryID, COUNT(*) as Count
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 0;

-- Ripeti lo stesso approccio per le altre tabelle (Product, Region, State, Sales)

--2)
SELECT 
    S.SaleID,
    S.ProductID,
    S.RegionID,
    P.ProductName,
    C.CategoryName,
    ST.StateName,
    R.RegionName,
    CASE WHEN DATEDIFF(DAY, S.TransactionDate, GETDATE()) > 180 THEN 'True' ELSE 'False' END AS MoreThan180Days
FROM Sales S
JOIN Product P ON S.ProductID = P.ProductID
JOIN Category C ON P.CategoryID = C.CategoryID
JOIN State ST ON S.RegionID = ST.RegionID
JOIN Region R ON S.RegionID = R.RegionID;

--3)
SELECT 
    P.ProductID,
    P.ProductName,
    YEAR(S.TransactionDate) AS SaleYear,
    SUM(S.Amount) AS TotalRevenue
FROM Sales S
JOIN Product P ON S.ProductID = P.ProductID
GROUP BY P.ProductID, P.ProductName, YEAR(S.TransactionDate);

--4)
SELECT 
    ST.StateName,
    YEAR(S.TransactionDate) AS SaleYear,
    SUM(S.Amount) AS TotalRevenue
FROM Sales S
JOIN State ST ON S.RegionID = ST.RegionID
GROUP BY ST.StateName, YEAR(S.TransactionDate)
ORDER BY YEAR(S.TransactionDate), TotalRevenue DESC;

--5)
SELECT TOP 1
    C.CategoryName,
    COUNT(S.SaleID) AS TotalSales
FROM Sales S
JOIN Product P ON S.ProductID = P.ProductID
JOIN Category C ON P.CategoryID = C.CategoryID
GROUP BY C.CategoryName
ORDER BY TotalSales DESC;

--6)
SELECT 
    P.ProductID,
    P.ProductName
FROM Product P
LEFT JOIN Sales S ON P.ProductID = S.ProductID
WHERE S.SaleID IS NULL;


SELECT 
    P.ProductID,
    P.ProductName
FROM Product P
WHERE NOT EXISTS (SELECT 1 FROM Sales S WHERE S.ProductID = P.ProductID);

--7)
SELECT 
    P.ProductID,
    P.ProductName,
    MAX(S.TransactionDate) AS LastSaleDate
FROM Product P
LEFT JOIN Sales S ON P.ProductID = S.ProductID
GROUP BY P.ProductID, P.ProductName;

--8)
CREATE VIEW ProductView AS
SELECT 
    P.ProductID,
    P.ProductName,
    C.CategoryName
FROM Product P
JOIN Category C ON P.CategoryID = C.CategoryID;

--9)
CREATE VIEW GeoInfoView AS
SELECT 
    ST.StateID,
    ST.StateName,
    R.RegionName
FROM State ST
JOIN Region R ON ST.RegionID = R.RegionID;







